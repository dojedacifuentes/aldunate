# Estado del caso · Molina con Inmobiliaria Cerro Alegre Demo SpA

> CASO FICTICIO. Corte de los datos: 10 de abril de 2026. Generado con Claude Code el 29 de octubre de 2026 y
> revisado por el abogado a cargo: PENDIENTE.

<!--
FORMATO: - <estado> | <texto> | <fuente>
  consta · el documento lo dice
  falta · consta que falta algo
  verificar · no consta o depende de algo que no está en la carpeta
  contradiccion · dos documentos dicen cosas distintas
-->

## Partes y objeto

- consta | Arrendadora: Inmobiliaria Cerro Alegre Demo SpA. Arrendataria y clienta: Javiera Molina Soto | 01-contrato-arriendo.md, p. 1
- consta | Garantía entregada: $480.000 | 01-contrato-arriendo.md, cláusula octava, p. 1
- consta | La clienta quiere recuperar la garantía completa | 04-notas-reunion.md

## Cronología

- consta | 01-03-2025 · Firma del contrato | 01-contrato-arriendo.md, p. 1
- consta | 28-02-2026 · Entrega del inmueble, acta «sin observaciones» | 02-acta-entrega.md
- consta | 05-03-2026 · La clienta pide la devolución de la garantía | 03-correos.md
- consta | 20-03-2026 · La inmobiliaria ofrece devolver $330.000 y descontar $150.000 por pintura | 03-correos.md
- consta | 02-04-2026 · La clienta pide el presupuesto o la boleta del descuento | 03-correos.md
- verificar | Respuesta de la inmobiliaria al correo del 02-04-2026: NO CONSTA — VERIFICAR | 03-correos.md
- consta | 10-04-2026 · Reunión con la clienta | 04-notas-reunion.md

## Contradicciones

- contradiccion | El acta de entrega dice «sin observaciones»; la inmobiliaria descuenta $150.000 por pintura del dormitorio principal | 02-acta-entrega.md · 03-correos.md (20-03-2026)

## Documentos faltantes

- falta | Fotografías del inmueble el día de la entrega: la clienta dice tenerlas, no están en la carpeta | 04-notas-reunion.md
- falta | Presupuesto o boleta del descuento por pintura, que exige la cláusula octava | 01-contrato-arriendo.md, cláusula octava · 03-correos.md
- verificar | Si la clienta recibió los $330.000 ofrecidos: según la reunión, no los ha recibido; no hay comprobante | 04-notas-reunion.md

## Próximos pasos registrados

- consta | Pedir las fotografías a la clienta | 04-notas-reunion.md
- consta | Redactar una carta a la inmobiliaria | 04-notas-reunion.md

## Para revisión del abogado

- verificar | Plazo de restitución de 30 días: el texto consta en la cláusula octava; su cómputo y efectos los determina el abogado | 01-contrato-arriendo.md, cláusula octava
