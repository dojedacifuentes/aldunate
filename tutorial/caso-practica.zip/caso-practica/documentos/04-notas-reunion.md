# Notas de la reunión con la clienta

> DOCUMENTO FICTICIO, creado para practicar.

**Fecha.** 10 de abril de 2026. Notas del abogado a cargo.

- La clienta quiere recuperar la garantía completa.
- Dice tener fotografías del departamento el día de la entrega. **No están en la carpeta.**
- No ha recibido los $330.000 que la inmobiliaria ofreció devolver.
- Próximo paso acordado: pedir las fotografías y redactar una carta a la inmobiliaria.
