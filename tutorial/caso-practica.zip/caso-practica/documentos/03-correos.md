# Correos intercambiados (transcripción)

> DOCUMENTO FICTICIO, creado para practicar.

## 5 de marzo de 2026 · De Javiera Molina a la inmobiliaria
Solicito la devolución de la garantía de $480.000, conforme a la cláusula octava. Entregué el departamento el 28 de febrero.

## 20 de marzo de 2026 · De la inmobiliaria a Javiera Molina
Devolveremos $330.000. Descontamos $150.000 por pintura del dormitorio principal.

## 2 de abril de 2026 · De Javiera Molina a la inmobiliaria
El acta de entrega dice «sin observaciones». Solicito el presupuesto o la boleta del descuento. *(Sin respuesta registrada a la fecha de corte.)*
