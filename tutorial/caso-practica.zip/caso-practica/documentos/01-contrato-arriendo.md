# Contrato de arrendamiento (transcripción)

> DOCUMENTO FICTICIO, creado para practicar. Personas, empresa, montos y fechas son inventados.

**Partes.** Inmobiliaria Cerro Alegre Demo SpA, arrendadora, y Javiera Molina Soto, arrendataria.

**Fecha de firma.** 1 de marzo de 2025.

**Inmueble.** Departamento 402, calle Ficticia 1234, Valparaíso.

**Cláusula tercera. Renta.** $480.000 mensuales, pagaderos dentro de los cinco primeros días de cada mes.

**Cláusula cuarta. Plazo.** Un año desde la firma, renovable por períodos iguales si ninguna parte avisa su término con 60 días de anticipación.

**Cláusula octava. Garantía.** La arrendataria entrega $480.000 en garantía. La arrendadora la restituirá dentro de los 30 días siguientes a la entrega del inmueble, descontando solo los deterioros que se acrediten con el acta de entrega y su respectivo presupuesto o boleta.

*Página 1 de 3 del original escaneado.*
