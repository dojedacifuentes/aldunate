# Acta de entrega del inmueble (transcripción)

> DOCUMENTO FICTICIO, creado para practicar.

**Fecha.** 28 de febrero de 2026.

**Comparecen.** Javiera Molina Soto y Andrés Pino, en representación de Inmobiliaria Cerro Alegre Demo SpA.

**Estado del inmueble.** Se revisan living, cocina, baño y dos dormitorios. **Sin observaciones.**

**Llaves.** Se entregan tres juegos de llaves y un control de portón.

**Firmas.** Firmada por ambos comparecientes.

*Página única del original escaneado.*
